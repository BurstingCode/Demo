﻿using System.Windows.Forms;

namespace RW.Ring.Helm
{
  public partial class MainForm : Form
  {
    public MainForm()
    {
      this.InitializeComponent();
    }
  }
}
