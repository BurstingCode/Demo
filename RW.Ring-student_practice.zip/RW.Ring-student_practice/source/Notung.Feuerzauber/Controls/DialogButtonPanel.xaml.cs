﻿using System.Windows.Controls;

namespace Notung.Feuerzauber.Controls
{
  /// <summary>
  /// Логика взаимодействия для DialogButtonPanel.xaml
  /// </summary>
  public partial class DialogButtonPanel : UserControl
  {
    public DialogButtonPanel()
    {
      this.InitializeComponent();
    }
  }
}
