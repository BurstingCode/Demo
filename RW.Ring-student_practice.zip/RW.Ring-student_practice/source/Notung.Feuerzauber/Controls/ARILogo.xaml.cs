﻿using System.Windows.Controls;

namespace Notung.Feuerzauber.Controls
{
  /// <summary>
  /// Логика взаимодействия для ARILogo.xaml
  /// </summary>
  public partial class ARILogo : UserControl
  {
    public ARILogo()
    {
      this.InitializeComponent();
    }
  }
}
