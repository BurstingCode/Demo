﻿using System.Windows;

namespace Notung.Feuerzauber.Dialogs
{
  /// <summary>
  /// Логика взаимодействия для AboutBox.xaml
  /// </summary>
  public partial class AboutBox : Window
  {
    public AboutBox()
    {
      this.InitializeComponent();
    }
  }
}
