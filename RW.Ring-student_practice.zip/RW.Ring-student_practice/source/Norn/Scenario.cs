﻿namespace Norn
{
  public class Scenario
  {
  }
}
